nuke.pluginAddPath('./inputFetcher_v1.0')
