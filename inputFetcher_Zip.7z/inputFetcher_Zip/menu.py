from inputFetcher import *
from inputFetcherCopyPaste import *